import { InMemoryDbService } from 'angular-in-memory-web-api';

export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const employees = [
      { id: 11, name: 'Govardhan', employeeLastName:'Goud' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 12, name: 'Nagul', employeeLastName:'Shaik' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 13, name: 'Mallik', employeeLastName:'Kinthada' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 14, name: 'Hazrath', employeeLastName: 'Rao' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 15, name: 'Srinivas', employeeLastName: 'kasi' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 16, name: 'Chandu' , employeeLastName:'chandu',mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 17, name: 'Rakesh' , employeeLastName:'klusldak',mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 18, name: 'Indra' ,employeeLastName:'haha',mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 19, name: 'Prakash', employeeLastName:'hello' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' },
      { id: 20, name: 'Rajesh', employeeLastName:'hai' ,mailId:'govi@gmail.com',phoneNumber:9898989898,password:'pass123',role:'Facullty',gender:'male',status:'Approve' }
    ];
    return {employees};
  }
}