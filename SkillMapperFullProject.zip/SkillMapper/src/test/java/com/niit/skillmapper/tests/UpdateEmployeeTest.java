package com.niit.skillmapper.tests;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.skillmapper.model.Employee;
import com.niit.skillmapper.services.EmployeeServices;

public class UpdateEmployeeTest {

	@Autowired
	static EmployeeServices employeeService;
	@BeforeClass
	public static void preExecution() {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit");
		context.refresh();
		
		employeeService = (EmployeeServices)context.getBean("employeeServices");
		
		
	}
    
	@Test
	public void updateEmployeeTest() {
		Employee employee=employeeService.displayEmployeeDetails("10001");
		employee.setName("Shaik");
	  	  employee.setEmployeeLastName("Nagul");
	  	  employee.setMailId("nagul.shaik@gmail.com");
	  	  employee.setGender("male");
	  	  employee.setPhoneNumber(8247454545L);
	  	  employee.setRole("Tech Mentor");
	  	  employee.setPassword("nagul123");
		  assertEquals("Updated Successfully", true,employeeService.updateEmployee(employee));
	}

}
